$(document).ready(function(){
	
});

    // 프로필 설정으로 이동
    function fnMyPage(){
        location.href='/nearby/member/mypage';        
    }
    
    